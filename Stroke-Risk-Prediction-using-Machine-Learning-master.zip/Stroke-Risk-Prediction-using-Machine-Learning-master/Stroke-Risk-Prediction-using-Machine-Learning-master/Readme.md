Tutorial Link of First Part (Train and Test):- https://youtu.be/JzgG-fiQAVI

Tutorial Link of Second Part (Web Deployment):- https://youtu.be/xP8HqUIIOFo
